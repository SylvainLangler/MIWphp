# DAY 3

Exo.

* `clone` this git
* run : `composer install` to fetch 3rd party

## Todo : 

* Clean and optimize HTML code, for speed, accessibility, social sharing, etc.
* Add CSS to get a nice responsive form. (CSS framework not allow)
* Develop email responsive which fit well on Gmail / Yahoo and Thunderbird client.
  
Design form XD :  https://xd.adobe.com/view/6e443a70-4484-44e7-4638-8a584f571eb8-1875/
 
TEST on your mobile, TEST on your device, TEST, TEST, TEST...  and Have fun !