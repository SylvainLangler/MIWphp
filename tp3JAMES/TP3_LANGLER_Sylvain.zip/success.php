<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Inscription Christmas Party</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <main>
            <div class="success">
                
            </div>
        </main>
    </body>
</html>