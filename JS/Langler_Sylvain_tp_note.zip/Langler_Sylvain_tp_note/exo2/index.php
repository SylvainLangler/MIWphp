<!DOCTYPE html>
<html lang='FR'>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>

<body>
    <main>
        <input list="villes" id="input_ville" onKeyUp="ajaxJSON_villes(this)">
    </main>
</body>
<script src="app.js"></script>

</html>