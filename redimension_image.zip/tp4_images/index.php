<!DOCTYPE html>
<html lang='fr'>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    </head>
    <body>
        <header>
        </header>
        <main>
            <form enctype="multipart/form-data" action="image.php" method="post">
            Nom : <input type="text" name="nom"><br />
            Photo : <input type="file" name="photo"><br />
            <input type="submit" value="Envoyer">
            </form>
        </main>
    </body>
</html>