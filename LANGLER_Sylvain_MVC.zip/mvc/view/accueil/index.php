<a href="<?php echo ROOT ?>livre/liste">Livres</a>
<br />
<br />
<a href="<?php echo ROOT ?>auteur/liste">Auteurs</a>